import React, { useEffect, useState } from 'react'
import axios from 'axios';
import AuthorForm from '../components/AuthorForm';
import AuthorList from '../components/AuthorList';
import { useNavigate } from 'react-router-dom';


export default () => {
    const [authors, setAuthors] = useState([]);
    const [loaded, setLoaded] = useState(false);
    const [errors, setErrors] = useState(null); 
    useEffect(() => {
        axios.get('http://localhost:8000/api/author')
            .then(res => {
                setAuthors(res.data)
                setLoaded(true);
            });
    }, [])

    const navigate = useNavigate();

    const removeFromDom = authorId => {
        setAuthors(authors.filter(author => author._id != authorId));
    }
    const createAuthor = author => {
        axios.post('http://localhost:8000/api/author', author)
            .then(res => {
                setAuthors([...authors, res.data]);
                navigate('/authors/')
            })
            .catch((error) => {
                console.log(error.response)
                setErrors(error.response?.data?.errors)
            
    })
}
    return (
        <div>
            <AuthorForm onSubmitProp={createAuthor} initialFirstName="" initialLastName="" errors = {errors} />
            <hr />
        </div>
    )
}