import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import DeleteButton from './DeleteButton';

const AuthorList = (props) => {
    // const [authors, setPeople] = useState([]);

    // useEffect(() => {
    //     axios.get('http://localhost:8000/api/author')
    //         .then(res => setPeople(res.data));
    // }, [])

    // const removeFromDom = authorId => {
    //     setPeople(authors.filter(author => author._id != authorId))
    // }
const {authors, removeFromDom} = props
    return (
        <div>
            <h1>Favorite Authors</h1>
            {authors.map((author, idx) => {
                return (
                    <p key={idx}>
                        <Link to={"/authors/" + author._id}>
                            {author.lastName}, {author.firstName}
                        </Link>
                        |
                        <Link to={"/authors/" + author._id + "/edit"}>
                            Edit
                        </Link>
                        |
                        <DeleteButton authorId={author._id} successCallback={() => removeFromDom(author._id)} />
                    </p>
                )
            })}
        </div>
    );
}

export default AuthorList;