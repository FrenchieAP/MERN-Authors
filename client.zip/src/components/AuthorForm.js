import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Link } from 'react-router-dom'
export default props => {
    const { initialFirstName, initialLastName, onSubmitProp } = props;
    const [firstName, setFirstName] = useState(initialFirstName);
    const [lastName, setLastName] = useState(initialLastName);
    const {errors} = props
    
    const onSubmitHandler = e => {
        e.preventDefault();
        onSubmitProp({firstName, lastName});
    }
        
    return (
        <>
        <h1>Favorite Authors</h1>
        <form onSubmit={onSubmitHandler}>

            <p>
                <label>First Name</label><br />
                <input 
                    type="text" 
                    name="firstName" value={firstName} 
                    onChange={(e) => { setFirstName(e.target.value) }} />
            </p>
            {
                errors?.firstName && (
                    <p>{errors.firstName?.message}</p>
                    
                )
            }
            <p>
                <label>Last Name</label><br />
                <input 
                    type="text" 
                    name="lastName" 
                    value={lastName} 
                    onChange={(e) => { setLastName(e.target.value) }} />
            </p>
            {
                errors?.lastName && (
                    <span>{errors.lastName?.message}</span>
                    
                )
            }
            <button className='btn'>Submit</button>
        </form>
        <Link to={"/authors/"}> 
            <button className='btn'>Cancel</button>
        </Link>
        </>
    )
}